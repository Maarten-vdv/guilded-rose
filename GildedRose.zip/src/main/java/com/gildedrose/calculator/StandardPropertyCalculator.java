package com.gildedrose.calculator;

public class StandardPropertyCalculator implements PropertyCalculator {
}
